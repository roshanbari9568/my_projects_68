-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 12, 2018 at 06:17 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `roshan`
--

-- --------------------------------------------------------

--
-- Table structure for table `onlineq`
--

CREATE TABLE IF NOT EXISTS `onlineq` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Person` varchar(20) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Phno` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `state` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `Message` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `onlineq`
--

INSERT INTO `onlineq` (`id`, `Person`, `Name`, `Phno`, `Email`, `state`, `city`, `Message`) VALUES
(1, '', 'abcd', '8108231143', 'roshan22.cb@gmail.com', '', '', 'zxvxfxbd'),
(2, '', 'hello', 'hello', 'hello', '', '', 'hello'),
(3, '', 'hello', 'hello', 'hello', '', '', 'hello'),
(4, '', 'roshanbari', 'roshanbari', 'roshanbari', '', '', 'roshanbari'),
(5, 'Miss', 'roshanbari', 'roshanbari', 'roshanbari', '', '', 'roshanbari'),
(6, 'Mr', 'xfgxgfxg', 'dxghxdgg', 'dfgxdgxdg', '', '', 'xdgfdxgdxg'),
(7, 'Mr', 'xfgxgfxg', 'dxghxdgg', 'dfgxdgxdg', '', '', 'xdgfdxgdxg'),
(8, 'Miss', 'snehaba', 'snehaba', 'snehaba', 'AP', '', ''),
(9, 'Miss', 'snehaba', 'snehaba', 'snehaba', 'AP', '', ''),
(10, '', 'Miss', 'snehaba', 'snehaba', 'snehaba', 'AP', ''),
(11, 'Miss', 'snehaba', 'snehaba', 'snehaba', 'AP', '', ''),
(12, 'Mrs', 'gxdhgxh', 'fgghcfghfdh', 'fgghfghh', 'BR', 'cfghcfdhcfh', 'fdhdhch'),
(13, 'Mr', 'sneha95686282', '8108231143', 'sneha@gmail.com', 'BR', 'region1', 'dhdxhgxdhxdh');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `aadhar` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `aadhar`, `email`, `phone`, `password`) VALUES
(19, 'roshanroshan4', 'roshanroshan4', 'roshanroshan4', 'roshanroshan4', 'roshanroshan4'),
(18, 'roshanroshan2', 'roshanroshan2', 'roshanroshan2', 'roshanroshan2', 'roshanroshan2'),
(17, 'roshanroshan', 'roshanroshan', 'roshanroshan', 'roshanroshan', 'roshanroshan'),
(16, 'hello', 'hello', 'hello', 'hello', 'hello'),
(15, 'aaaa', 'aaaa', 'aaaa', 'aaaa', 'aaaa'),
(14, 'abcd1', 'abcd1', 'abcd1', 'abcd1', 'abcd1'),
(13, 'abcd', 'abcd', 'abcd', 'abcd', 'abcd');
