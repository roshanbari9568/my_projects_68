-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 12, 2018 at 06:16 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `company`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'roshanb', 'roshanb'),
(2, 'snehab', 'snehab'),
(3, 'abcd', 'abcd'),
(4, 'abli', 'abli'),
(5, 'abcdya', 'abcdya'),
(6, 'abef', 'abef'),
(7, 'miroshan', 'miroshan'),
(8, 'vakdya', 'vakdya'),
(9, 'harsh', 'harsh');

-- --------------------------------------------------------

--
-- Table structure for table `userloginthroughadmin`
--

CREATE TABLE IF NOT EXISTS `userloginthroughadmin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobileno` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `dateofreg` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `userloginthroughadmin`
--

INSERT INTO `userloginthroughadmin` (`id`, `username`, `password`, `mobileno`, `address`, `dateofreg`) VALUES
(1, 'harsh', 'harsh', '', '', ''),
(2, 'sneha', 'sneha', '', 'mumbai', '2018-08-23'),
(3, 'roshan9568', 'roshan9568', 'roshan9568', 'roshan9568', '2018-08-31');
