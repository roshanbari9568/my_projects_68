-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 12, 2018 at 06:14 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'roshan68', 'roshan68');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `cylprice` varchar(255) NOT NULL,
  `mobileno` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `cardno` varchar(255) NOT NULL,
  `cvv` varchar(10) NOT NULL,
  `cardexpdate` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `order`
--


-- --------------------------------------------------------

--
-- Table structure for table `pm`
--

CREATE TABLE IF NOT EXISTS `pm` (
  `id` bigint(20) NOT NULL,
  `id2` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `user1` bigint(20) NOT NULL,
  `user2` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `timestamp` int(10) NOT NULL,
  `user1read` varchar(3) NOT NULL,
  `user2read` varchar(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pm`
--

INSERT INTO `pm` (`id`, `id2`, `title`, `user1`, `user2`, `message`, `timestamp`, `user1read`, `user2read`) VALUES
(1, 1, 'hey', 2, 1, 'wassap', 1532957660, 'yes', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `image` longblob NOT NULL,
  `image2` longblob NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `avatar` text NOT NULL,
  `signup_date` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `image`, `image2`, `password`, `email`, `avatar`, `signup_date`) VALUES
(1, 'hello', '', '', 'hello9568', 'loverboysuraj220@gmail.com', 'abcd', 1532957389),
(2, 'abcd', '', '', 'abcd9568', 'roshan22.cb@gmail.com', 'hello', 1532957568),
(8, 'papdya', '', '', 'papdya', 'papdya@gmail.com', 'papdya', 1533653816),
(7, 'mumdya', '', '', 'mumdya', 'mumdya@gmail.com', 'mumdya', 1533653396),
(6, 'roshdya', '', '', 'roshdya', 'roshdya@gmail.com', 'roshdya', 1533653254),
(5, 'snehdya', '', '', 'snehdya', 'snehdya@gmail.com', 'snehdya', 1533651367),
(4, 'pqrs1', '', '', 'pqrs19568', 'pqrs1@gmail.com', 'pqrs1', 1533464705),
(3, 'pqrs', '', '', 'pqrs9568', 'pqrs@gmail.com', 'pqrs', 1533464587),
(9, 'nandya', '', '', 'nandya', 'nandya@gmail.com', 'nandya', 1533654188),
(10, 'papdya2', '', '', 'papdya2', 'papdya2@gmail.com', 'papdya2', 1533654361),
(11, 'roshanb23', '', '', 'roshanb23', 'roshanb23@gmail.com', 'roshanb23', 1533654425),
(12, 'abdya1', 0x696d616765735f322e6a706567, '', 'abdya1', 'abdya1@gmail.com', 'abdya1', 1533662073),
(13, 'bvimit', 0x313338333530335f3632363730353438373337323834305f313736303233393333355f6e2e6a7067, '', 'bvimit', 'bvimit@gmail.com', 'bvimit', 1533830450),
(14, 'abcidya', 0x32202831292e6a7067, '', 'abcidya', 'abcidya@gmail.com', 'abcidya', 1533833224),
(15, 'roshaba', 0x73657175656e6365206469616772616d20746f7572206d676d742e4a5047, '', 'roshaba9568', 'roshaba@gmail.com', 'roshaba', 1533988123),
(16, 'sneha95686282', 0x627574746f6e2d313135373239395f3936305f3732302e706e67, '', 'sneha95686282', 'sneha95686282@gmail.com', 'sneha95686282', 1534051965);
